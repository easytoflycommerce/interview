package com.interview.weather

sealed class CityOrder {
    data class Country(val name: String): CityOrder()

    data class City(val name: String): CityOrder()
}