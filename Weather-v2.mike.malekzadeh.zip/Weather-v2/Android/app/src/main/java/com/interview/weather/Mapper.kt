package com.interview.weather

class Mapper {
    fun map(cities: MutableList<City>): List<CityOrder> {
        val models = mutableListOf<CityOrder>()

        cities.groupBy { it.countryName }
            .toSortedMap { a, b ->
                a.compareTo(b)
            }
            .map {
                models.add(CityOrder.Country(it.key))
                val sortedCity = it.value.sortedBy { city -> city.name }
                sortedCity.forEach { city ->
                    models.add(CityOrder.City(city.name))
                }
        }

        return models
    }
}