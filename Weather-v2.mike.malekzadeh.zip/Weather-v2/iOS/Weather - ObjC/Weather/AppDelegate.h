//
//  AppDelegate.h
//  Weather
//
//  Copyright © 2019 Uber. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WeatherTableViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

