//
//  WeatherTableViewController.swift
//  Weather
//
//  Copyright © 2018 Uber. All rights reserved.
//

import UIKit

class WeatherTableViewController: UITableViewController {

    var citiesResponse: GetCitiesResponse?

    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "DefaultCell")

        let service = WeatherService()
        citiesResponse = service.waitForCities()
        let weatherCityResponse = service.waitForWeather(forCity: "sanfrancisco")

        print(citiesResponse?.cities.first?.name ?? "")
        print(weatherCityResponse?.currentWeather.longDescription ?? "")
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return citiesResponse?.cities.count ?? 0
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DefaultCell", for: indexPath)
        cell.textLabel?.text = citiesResponse?.cities[indexPath.row].name
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // no-op (for now)
    }
}

