//
//  WeatherService.h
//  Weather
//
//  Copyright © 2017 Uber. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "City.h"
#import "CurrentWeather.h"
#import "PredictedWeather.h"
#import "GetCitiesResponse.h"
#import "GetWeatherForCityResponse.h"

typedef void (^WeatherServiceGetCitiesCompletionBlock)(GetCitiesResponse * response);

typedef void (^WeatherServiceGetWeatherForCityCompletionBlock)(GetWeatherForCityResponse * response);

@interface WeatherService : NSObject

// a synchronous call to get the list of cities
- (GetCitiesResponse *)waitForCities;
- (GetCitiesResponse *)waitForCities:(BOOL)randomize;

// a synchronous call to get the weather given a city name
- (GetWeatherForCityResponse *)waitForWeatherForCity:(NSString *)cityName;

// an asynchronous call to get the list of cities
- (void)getCities:(BOOL)randomize onCompletion:(WeatherServiceGetCitiesCompletionBlock)completion;

// an asynchronous call to get the weather given a city name
- (void)getWeatherForCity:(NSString *)cityName onCompletion:(WeatherServiceGetWeatherForCityCompletionBlock)completion;

@end
